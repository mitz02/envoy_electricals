<script setup>
import { ref, computed } from 'vue';
import { Link } from '@inertiajs/vue3';
import { cartCount } from '../lib/cart';
import SiteFooter from '../Components/SiteFooter.vue';

const isMobileMenuOpen = ref(false);

const whatsappNumber = '2348097089259';
const whatsapp = computed(() => whatsappNumber.replace(/\D/g, ''));
const whatsappUrl = computed(() => `https://wa.me/${whatsapp.value}`);

const navLinks = [
    { label: 'Home', href: '/' },
    { label: 'Buy Our Products', href: '/shop' },
    { label: 'Packages', href: '/packages' },
    { label: 'Free Calculator', href: '/calculator' },
    { label: 'About Us', href: '/about' },
    { label: 'Training', href: '/portal' },
];
</script>

<template>
    <div class="min-h-screen bg-[#FAF8F2]">
        <!-- HEADER -->
        <header class="sticky top-0 left-0 right-0 z-40 border-b border-slate-200 bg-white shadow-sm">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 sm:h-18 flex items-center justify-between gap-4">
                <Link href="/" class="flex items-center shrink-0">
                    <img src="/envoy_images/logo.png" alt="Envoy Electricals" class="h-9 sm:h-10 w-auto object-contain" />
                </Link>

                <nav class="hidden lg:flex items-center gap-7">
                    <Link
                        v-for="l in navLinks"
                        :key="l.href"
                        :href="l.href"
                        class="text-sm font-semibold text-slate-700 hover:text-slate-950 relative after:absolute after:left-0 after:-bottom-1.5 after:h-[2px] after:w-0 after:bg-yellow-400 hover:after:w-full after:transition-all after:duration-300 transition-colors"
                    >
                        {{ l.label }}
                    </Link>
                    <Link href="/contact" class="text-sm font-semibold text-slate-700 hover:text-slate-950 relative after:absolute after:left-0 after:-bottom-1.5 after:h-[2px] after:w-0 after:bg-yellow-400 hover:after:w-full after:transition-all after:duration-300 transition-colors">
                        Contact
                    </Link>
                </nav>

                <div class="flex items-center gap-3 sm:gap-4 shrink-0">
                    <!-- "Let's talk" Pill Button -->
                    <a
                        :href="whatsappUrl"
                        target="_blank"
                        rel="noopener noreferrer"
                        class="inline-flex items-center justify-center px-5 sm:px-6 py-2 rounded-full border border-slate-300 bg-white hover:bg-slate-950 hover:text-white hover:border-slate-950 text-slate-900 text-xs sm:text-sm font-medium transition-all duration-300"
                    >
                        Let's talk
                    </a>

                    <Link
                        href="/cart"
                        title="Cart"
                        class="relative w-8 sm:w-10 h-8 sm:h-10 rounded-full border border-slate-300 flex items-center justify-center text-slate-900 hover:border-yellow-400 hover:bg-yellow-400 hover:text-slate-950 transition-all duration-200"
                    >
                        <svg class="w-4 sm:w-5 h-4 sm:h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="9" cy="21" r="1" />
                            <circle cx="20" cy="21" r="1" />
                            <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
                        </svg>
                        <span v-if="cartCount > 0" class="absolute -top-1.5 -right-1.5 min-w-4 h-4 rounded-full bg-[#E4312B] text-white text-[10px] font-black flex items-center justify-center px-1">
                            {{ cartCount }}
                        </span>
                    </Link>

                    <Link
                        v-if="$page.props.auth?.user"
                        :href="route('dashboard')"
                        title="Dashboard"
                        class="w-10 h-10 rounded-full border border-slate-300 flex items-center justify-center text-slate-900 hover:border-yellow-400 hover:bg-yellow-400 hover:text-slate-950 transition-all duration-200"
                    >
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                        </svg>
                    </Link>
                    <Link
                        v-else
                        :href="route('login')"
                        title="Sign In"
                        class="w-10 h-10 rounded-full border border-slate-300 flex items-center justify-center text-slate-900 hover:border-yellow-400 hover:bg-yellow-400 hover:text-slate-950 transition-all duration-200"
                    >
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                        </svg>
                    </Link>

                    <button
                        type="button"
                        class="lg:hidden w-8 sm:w-9 flex flex-col justify-center items-end gap-1.5 p-1 group focus:outline-none"
                        @click="isMobileMenuOpen = !isMobileMenuOpen"
                        aria-label="Toggle menu"
                    >
                        <span class="w-6 sm:w-7 h-[2px] bg-slate-900 transition-all duration-300 group-hover:bg-yellow-400"></span>
                        <span class="w-6 sm:w-7 h-[2px] bg-slate-900 transition-all duration-300 group-hover:bg-yellow-400"></span>
                    </button>
                </div>
            </div>
        </header>

        <!-- MOBILE DRAWER -->
        <div v-if="isMobileMenuOpen" class="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex justify-end" @click.self="isMobileMenuOpen = false">
            <div class="w-full max-w-sm bg-[#0B132B] h-full p-8 flex flex-col justify-between shadow-2xl border-l border-white/10 overflow-y-auto">
                <div>
                    <div class="flex items-center justify-between pb-6 border-b border-white/10">
                        <div class="flex items-center gap-3">
                            <img src="/envoy_images/logo.png" alt="Envoy Electricals" class="h-10 w-auto object-contain bg-white rounded-lg p-1" />
                        </div>
                        <button type="button" class="text-white/70 hover:text-white text-2xl font-bold p-1" @click="isMobileMenuOpen = false">✕</button>
                    </div>
                    <nav class="mt-8 space-y-4">
                        <a
                            href="#hero"
                            @click="isMobileMenuOpen = false"
                            class="block text-lg font-semibold text-white/90 hover:text-yellow-400 transition"
                        >
                            Home
                        </a>
                        <Link
                            href="/training"
                            @click="isMobileMenuOpen = false"
                            class="block text-lg font-semibold text-white/90 hover:text-yellow-400 transition"
                        >
                            Training
                        </Link>
                        <a
                            href="/packages"
                            @click="isMobileMenuOpen = false"
                            class="block text-lg font-semibold text-white/90 hover:text-yellow-400 transition"
                        >
                            Packages
                        </a>
                        <a
                            href="/shop"
                            @click="isMobileMenuOpen = false"
                            class="flex items-center justify-between text-lg font-semibold text-white/90 hover:text-yellow-400 transition"
                        >
                            <span>Buy Our Products</span>
                            <span class="relative flex items-center justify-center">
                                <svg class="w-5 h-5 text-white/80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <circle cx="9" cy="21" r="1" />
                                    <circle cx="20" cy="21" r="1" />
                                    <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
                                </svg>
                                <span
                                    v-if="cartCount > 0"
                                    class="absolute -top-2 -right-2 min-w-[18px] h-[18px] rounded-full bg-[#E4312B] text-white text-[10px] font-black flex items-center justify-center px-1"
                                >
                                    {{ cartCount }}
                                </span>
                            </span>
                        </a>
                        <a
                            :href="route('about')"
                            @click="isMobileMenuOpen = false"
                            class="block text-lg font-semibold text-white/90 hover:text-yellow-400 transition"
                        >
                            About Us
                        </a>
                        <a
                            :href="route('contact')"
                            @click="isMobileMenuOpen = false"
                            class="block text-lg font-semibold text-white/90 hover:text-yellow-400 transition"
                        >
                            Contact
                        </a>
                        <a
                            :href="route('calculator')"
                            @click="isMobileMenuOpen = false"
                            class="block text-lg font-semibold text-white/90 hover:text-yellow-400 transition"
                        >
                            Load Calculator
                        </a>
                    </nav>
                </div>

                <div class="pt-6 border-t border-white/10 space-y-3">
                    <a
                        :href="whatsappUrl"
                        target="_blank"
                        rel="noopener noreferrer"
                        class="w-full py-3 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-bold rounded-full text-center transition block"
                    >
                        Let's Talk
                    </a>
                    <Link
                        v-if="!$page.props.auth?.user"
                        :href="route('login')"
                        class="w-full py-3 border border-white/30 text-white font-semibold rounded-full text-center block hover:bg-white/10 transition"
                    >
                        Sign In / Staff Portal
                    </Link>
                    <Link
                        v-else
                        :href="route('dashboard')"
                        class="w-full py-3 border border-white/30 text-white font-semibold rounded-full text-center block hover:bg-white/10 transition"
                    >
                        Dashboard
                    </Link>
                </div>
            </div>
        </div>

        <!-- PAGE CONTENT -->
        <main>
            <slot />
        </main>

        <!-- FOOTER -->
        <SiteFooter estimate-href="/contact" />
    </div>
</template>