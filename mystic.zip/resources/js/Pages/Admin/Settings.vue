<script setup>
import { router, useForm } from '@inertiajs/vue3';
import AdminLayout from '@/Layouts/AdminLayout.vue';
import FlashMessages from '@/Components/FlashMessages.vue';
import PageHeader from '@/Components/PageHeader.vue';

defineOptions({ layout: AdminLayout });

const props = defineProps({
    categories: { type: Array, default: () => [] },
});

const form = useForm({
    name: '',
});

function addCategory() {
    if (!form.name.trim()) return;
    form.post('/admin/settings/categories', {
        preserveScroll: true,
        onSuccess: () => {
            form.reset('name');
        },
    });
}

function confirmDelete(category) {
    const linked = category.product_count > 0
        ? ` It has ${category.product_count} product${category.product_count === 1 ? '' : 's'} linked — they will be left uncategorised.`
        : '';
    if (window.confirm(`Delete category "${category.name}"?${linked} This can't be undone.`)) {
        router.delete(`/admin/settings/categories/${category.id}`, { preserveScroll: true });
    }
}
</script>

<template>
    <FlashMessages />
    <PageHeader title="Settings" subtitle="Manage the product categories used across your catalogue." />

    <div class="grid gap-6 lg:grid-cols-3">
        <!-- Categories list -->
        <div class="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-xs lg:col-span-2">
            <div class="mb-4 flex items-center justify-between">
                <h2 class="text-sm font-semibold text-slate-900">Product Categories</h2>
                <span class="rounded-full bg-[#0D1527]/5 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-[#0D1527]">
                    {{ categories.length }} categor{{ categories.length === 1 ? 'y' : 'ies' }}
                </span>
            </div>

            <div v-if="!categories.length" class="rounded-xl border border-dashed border-slate-200 py-10 text-center text-sm text-slate-400">
                No categories yet. Add your first one below.
            </div>

            <div v-else class="space-y-2">
                <div v-for="c in categories" :key="c.id" class="flex items-center gap-3 rounded-xl border border-slate-200 px-4 py-3">
                    <span class="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#0D1527] text-white">
                        <i class="bi bi-folder2-open text-sm"></i>
                    </span>
                    <div class="min-w-0 flex-1">
                        <p class="truncate text-sm font-semibold text-slate-800">{{ c.name }}</p>
                        <p class="text-[11px] text-slate-400">{{ c.slug }}</p>
                    </div>
                    <span
                        class="rounded-full px-2.5 py-1 text-[11px] font-semibold"
                        :class="c.product_count > 0 ? 'bg-teal-100 text-teal-800' : 'bg-slate-100 text-slate-500'"
                    >
                        {{ c.product_count }} product{{ c.product_count === 1 ? '' : 's' }}
                    </span>
                    <button
                        type="button"
                        title="Delete category"
                        class="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 transition hover:bg-red-50 hover:text-red-600"
                        @click="confirmDelete(c)"
                    >
                        <i class="bi bi-trash3 text-sm"></i>
                    </button>
                </div>
            </div>
        </div>

        <!-- Add category -->
        <div class="space-y-5">
            <div class="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-xs">
                <h2 class="mb-4 text-sm font-semibold text-slate-900">Add Category</h2>
                <form @submit.prevent="addCategory">
                    <div class="space-y-3">
                        <div>
                            <label class="mb-1 block text-sm font-medium text-slate-700">Name <span class="text-red-500">*</span></label>
                            <input v-model="form.name" type="text" placeholder="e.g. Micro Inverters" class="w-full rounded-lg border-slate-300 text-sm focus:border-amber-400 focus:ring-amber-400/20" />
                            <div v-if="form.errors.name" class="mt-1 text-xs text-red-600">{{ form.errors.name }}</div>
                        </div>
                        <button
                            type="submit"
                            class="flex w-full items-center justify-center gap-2 rounded-lg bg-[#0D1527] px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-[#0D1527]/90 disabled:opacity-50"
                            :disabled="form.processing || !form.name.trim()"
                        >
                            <i class="bi bi-plus-lg text-sm"></i>
                            {{ form.processing ? 'Adding…' : 'Add Category' }}
                        </button>
                    </div>
                </form>
                <p class="mt-3 text-xs text-slate-400">Categories are used on the product form and the online shop filters.</p>
            </div>
        </div>
    </div>
</template>