<script setup>
import { ref, computed } from 'vue';
import { useForm } from '@inertiajs/vue3';
import AdminLayout from '@/Layouts/AdminLayout.vue';
import FlashMessages from '@/Components/FlashMessages.vue';
import PageHeader from '@/Components/PageHeader.vue';
import { MASK_GLYPH } from '@/composables/permissions';

defineOptions({ layout: AdminLayout });

const props = defineProps({
    roles: { type: Array, default: () => [] },
    permission_modules: { type: Object, default: () => ({}) },
    maskable_fields: { type: Array, default: () => [] },
});

const staffRoles = computed(() => props.roles.filter((r) => !r.is_owner));
const selectedRole = ref(staffRoles.value[0] ?? null);

const moduleLabels = {
    dashboard: 'Dashboard',
    products: 'Products & Catalogue',
    inventory: 'Inventory & Stock',
    purchases: 'Purchases',
    suppliers: 'Suppliers',
    sales: 'Sales & POS',
    payments: 'Payments',
    customers: 'Customers & CRM',
    expenses: 'Expenses',
    projects: 'Projects',
    staff: 'Staff',
    payroll: 'Payroll',
    assets: 'Assets',
    solar: 'Solar',
    marketing: 'Marketing',
    website: 'Website',
    reports: 'Reports',
    settings: 'Settings',
    audit: 'Audit',
    orders: 'Online Orders',
    feedback: 'Feedback',
    training: 'Academy & Training',
};

const moduleIcons = {
    dashboard: 'bi-grid-1x2-fill',
    products: 'bi-box-seam-fill',
    inventory: 'bi-arrow-repeat',
    purchases: 'bi-basket-fill',
    suppliers: 'bi-buildings-fill',
    sales: 'bi-cart-check-fill',
    payments: 'bi-wallet2',
    customers: 'bi-people-fill',
    expenses: 'bi-receipt',
    projects: 'bi-lightning-charge-fill',
    staff: 'bi-person-badge-fill',
    payroll: 'bi-currency-dollar',
    assets: 'bi-bank',
    solar: 'bi-sun-fill',
    marketing: 'bi-megaphone-fill',
    website: 'bi-globe2',
    reports: 'bi-bar-chart-fill',
    settings: 'bi-gear',
    audit: 'bi-shield-check',
    orders: 'bi-bag-fill',
    feedback: 'bi-chat-dots',
    training: 'bi-mortarboard-fill',
};

const form = useForm({
    permissions: selectedRole.value ? [...selectedRole.value.permission_slugs] : [],
    masked_fields: selectedRole.value ? [...selectedRole.value.masked_fields] : [],
});

const activeCount = computed(() => form.permissions.length);
const activeMasked = computed(() => form.masked_fields.length);

function selectRole(role) {
    selectedRole.value = role;
    form.clearErrors();
    form.permissions = [...role.permission_slugs];
    form.masked_fields = [...role.masked_fields];
}

function togglePermission(slug) {
    const i = form.permissions.indexOf(slug);
    if (i === -1) form.permissions.push(slug);
    else form.permissions.splice(i, 1);
}

function toggleMask(slug) {
    const i = form.masked_fields.indexOf(slug);
    if (i === -1) form.masked_fields.push(slug);
    else form.masked_fields.splice(i, 1);
}

function toggleModule(module, slugs) {
    const on = slugs.every((s) => form.permissions.includes(s));
    if (on) {
        form.permissions = form.permissions.filter((s) => !slugs.includes(s));
    } else {
        form.permissions = [...new Set([...form.permissions, ...slugs])];
    }
}

const sampleValue = (field) => (field.type === 'percent' ? '42.5%' : '₦1,240,500');

function submit() {
    form.post(`/admin/settings/roles/${selectedRole.value.id}`, {
        preserveScroll: true,
    });
}
</script>

<template>
    <FlashMessages />
    <PageHeader title="Roles & Access" subtitle="Choose which menus staff roles can see and which sensitive values appear masked on screen." />

    <!-- Role selector -->
    <div class="mb-6 flex flex-wrap gap-2">
        <button
            v-for="role in staffRoles"
            :key="role.id"
            type="button"
            @click="selectRole(role)"
            class="inline-flex items-center gap-2 rounded-xl border px-4 py-2.5 text-sm font-bold transition-all"
            :class="selectedRole?.id === role.id ? 'border-[#0D1527] bg-[#0D1527] text-white shadow-md' : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'"
        >
            <i class="bi bi-person-badge"></i>
            {{ role.name }}
            <span class="rounded-full px-1.5 py-0.5 text-[10px]" :class="selectedRole?.id === role.id ? 'bg-yellow-400 text-[#0D1527]' : 'bg-slate-100 text-slate-500'">
                {{ role.staff_count }}
            </span>
        </button>
    </div>

    <p class="mb-5 text-xs text-slate-400">
        Owner / Super Admin always has full access — it cannot be edited here.
    </p>

    <form v-if="selectedRole" @submit.prevent="submit" class="grid gap-6 lg:grid-cols-3">
        <!-- Menus & permissions -->
        <div class="rounded-2xl border border-slate-200/80 bg-white shadow-xs lg:col-span-2">
            <div class="flex items-center justify-between border-b border-slate-100 px-5 py-4">
                <div class="flex items-center gap-2.5">
                    <span class="flex h-9 w-9 items-center justify-center rounded-xl bg-[#0D1527] text-[#40e0d0]">
                        <i class="bi bi-layout-sidebar"></i>
                    </span>
                    <div>
                        <h2 class="text-sm font-black text-slate-900">Menus & permissions</h2>
                        <p class="text-xs text-slate-400">These control which menu items “{{ selectedRole.name }}” staff see in the sidebar.</p>
                    </div>
                </div>
                <span class="rounded-full bg-[#0D1527]/5 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-[#0D1527]">
                    {{ activeCount }} selected
                </span>
            </div>

            <div class="grid gap-4 p-5 sm:grid-cols-2">
                <div v-for="(perms, module) in permission_modules" :key="module" class="rounded-xl border border-slate-100 p-4">
                    <div class="mb-3 flex items-center justify-between gap-2">
                        <h3 class="flex items-center gap-2 text-xs font-black uppercase tracking-wide text-slate-700">
                            <i :class="['bi', moduleIcons[module] || 'bi-folder']" class="text-[#40e0d0]"></i>
                            {{ moduleLabels[module] || module }}
                        </h3>
                        <button
                            type="button"
                            @click="toggleModule(module, perms.map((p) => p.slug))"
                            class="rounded-md px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide transition"
                            :class="perms.every((p) => form.permissions.includes(p.slug)) ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'"
                        >
                            {{ perms.every((p) => form.permissions.includes(p.slug)) ? 'On' : 'Off' }}
                        </button>
                    </div>
                    <div class="space-y-1.5">
                        <label
                            v-for="perm in perms"
                            :key="perm.slug"
                            class="flex cursor-pointer items-center gap-2.5 rounded-lg px-2 py-1.5 transition hover:bg-slate-50"
                        >
                            <input
                                type="checkbox"
                                :checked="form.permissions.includes(perm.slug)"
                                @change="togglePermission(perm.slug)"
                                class="h-4 w-4 rounded accent-yellow-500"
                            />
                            <span class="min-w-0">
                                <span class="block text-[13px] font-semibold text-slate-700">{{ perm.name }}</span>
                                <span class="block truncate text-[11px] text-slate-400">{{ perm.description }}</span>
                            </span>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <!-- Masked fields -->
        <div class="space-y-6">
            <div class="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-xs">
                <div class="mb-1 flex items-center gap-2.5">
                    <span class="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-100 text-amber-600">
                        <i class="bi bi-eye-slash"></i>
                    </span>
                    <div>
                        <h2 class="text-sm font-black text-slate-900">Hidden values (asterisks)</h2>
                        <p class="text-xs text-slate-400">Sensitive figures show as {{ MASK_GLYPH }} for this role.</p>
                    </div>
                </div>
                <span class="mt-2 inline-block rounded-full bg-amber-100 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-amber-800">
                    {{ activeMasked }} of {{ maskable_fields.length }} masked
                </span>

                <div class="mt-4 space-y-2">
                    <label
                        v-for="field in maskable_fields"
                        :key="field.slug"
                        class="flex items-center justify-between gap-3 rounded-xl border border-slate-100 px-3.5 py-3 transition hover:border-amber-200"
                        :class="form.masked_fields.includes(field.slug) ? 'bg-amber-50' : 'bg-white'"
                    >
                        <span class="min-w-0">
                            <span class="flex items-center gap-2 text-[13px] font-semibold text-slate-800">
                                {{ field.label }}
                                <i v-if="form.masked_fields.includes(field.slug)" class="bi bi-eye-slash text-amber-500"></i>
                            </span>
                            <span class="mt-0.5 block truncate text-[11px] text-slate-400">{{ field.hint }}</span>
                        </span>
                        <span class="flex shrink-0 items-center gap-2">
                            <span class="font-mono text-xs" :class="form.masked_fields.includes(field.slug) ? 'text-amber-600' : 'text-slate-500'">
                                {{ form.masked_fields.includes(field.slug) ? MASK_GLYPH : sampleValue(field) }}
                            </span>
                            <input
                                type="checkbox"
                                :checked="form.masked_fields.includes(field.slug)"
                                @change="toggleMask(field.slug)"
                                class="h-4 w-4 rounded accent-yellow-500"
                            />
                        </span>
                    </label>
                </div>
            </div>

            <div class="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-xs">
                <h3 class="flex items-center gap-2 text-xs font-black uppercase tracking-wide text-slate-700">
                    <i class="bi bi-info-circle text-[#40e0d0]"></i> How it works
                </h3>
                <ul class="mt-3 space-y-2 text-xs leading-relaxed text-slate-500">
                    <li class="flex gap-2"><i class="bi bi-check2-circle text-emerald-500"></i> Unchecking a menu hides that item from the staff sidebar immediately.</li>
                    <li class="flex gap-2"><i class="bi bi-check2-circle text-emerald-500"></i> Masked values render as {{ MASK_GLYPH }} in the dashboard, reports, product cost and profit views.</li>
                    <li class="flex gap-2"><i class="bi bi-check2-circle text-emerald-500"></i> The owner role always sees everything.</li>
                </ul>
            </div>

            <div class="sticky bottom-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-lg">
                <div class="flex items-center justify-between gap-3">
                    <button
                        type="submit"
                        :disabled="form.processing"
                        class="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[#0D1527] px-5 py-3 text-sm font-bold text-white transition hover:bg-[#0D1527]/90 disabled:cursor-not-allowed disabled:opacity-60"
                    >
                        <i v-if="form.processing" class="bi bi-arrow-clockwise animate-spin"></i>
                        <i v-else class="bi bi-check2-square"></i>
                        {{ form.processing ? 'Saving…' : 'Save access for ' + selectedRole.name }}
                    </button>
                </div>
                <div v-if="form.errors.permissions || form.errors.masked_fields" class="mt-2 text-xs text-red-600">
                    {{ form.errors.permissions || form.errors.masked_fields }}
                </div>
            </div>
        </div>
    </form>
</template>