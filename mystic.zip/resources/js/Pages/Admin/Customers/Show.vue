<script setup>
import { useForm, Link } from '@inertiajs/vue3';
import AdminLayout from '@/Layouts/AdminLayout.vue';
import FlashMessages from '@/Components/FlashMessages.vue';
import PageHeader from '@/Components/PageHeader.vue';
import Pagination from '@/Components/Pagination.vue';
import { naira, formatDate, formatDateTime, badgeClass } from '@/lib/format';
import { useCan } from '@/composables/permissions';

defineOptions({ layout: AdminLayout });

const props = defineProps({
    customer: { type: Object, required: true },
    totals: { type: Object, default: () => ({ sales_sum: 0, outstanding: 0, count: 0 }) },
    payments: { type: Object, default: () => ({}) },
    payments_meta: { type: Object, default: () => ({ received: 0, paid_out: 0, count: 0 }) },
});

const { has } = useCan();

const outstanding = () => Number(props.totals.outstanding);

const form = useForm({
    amount: null,
    payment_method: 'cash',
    payment_date: new Date().toISOString().slice(0, 10),
    remarks: '',
});

const canSettle = () => has('payments.record') && outstanding() > 0;

function statusBadge(status) {
    const map = {
        success: 'bg-emerald-100 text-emerald-800',
        pending: 'bg-amber-100 text-amber-800',
        failed: 'bg-red-100 text-red-700',
        reversed: 'bg-slate-200 text-slate-600',
        refunded: 'bg-slate-200 text-slate-600',
    };
    return badgeClass(map[status] ?? 'bg-slate-200 text-slate-600');
}

const settle = () => {
    form.post(`/admin/customers/${props.customer.id}/settle`);
};
</script>

<template>
        <FlashMessages />
        <PageHeader
            :title="customer.name"
            :subtitle="customer.ref_id"
            :action-href="has('customers.manage') ? `/admin/customers/${customer.id}/edit` : ''"
            action-label="Edit"
        />

        <div
            v-if="Number(totals.outstanding) > 0"
            class="mb-4 flex items-start gap-3 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium leading-relaxed text-red-700"
            role="alert"
        >
            <i class="bi bi-exclamation-triangle-fill mt-0.5 text-red-500"></i>
            <span>
                This customer has an outstanding balance of
                <strong>{{ naira(totals.outstanding) }}</strong>
                across unpaid invoices.
            </span>
        </div>

        <div
            v-if="canSettle()"
            class="mt-4 rounded-2xl border border-slate-200/80 bg-white p-5 shadow-xs"
        >
            <div class="mb-3 flex items-center justify-between gap-4">
                <div>
                    <h2 class="text-sm font-semibold text-slate-900">Settle Due Payment</h2>
                    <p class="text-xs text-slate-400">
                        Payment applies to the oldest unpaid invoice first.
                    </p>
                </div>
                <button
                    type="button"
                    class="whitespace-nowrap text-xs font-semibold text-[#0D1527] underline underline-offset-2 hover:text-[#40e0d0]"
                    @click="form.amount = outstanding()"
                >
                    Amount = balance
                </button>
            </div>

            <div class="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                <div>
                    <label class="block text-xs font-medium text-slate-600">Amount</label>
                    <input
                        v-model="form.amount"
                        type="number"
                        step="0.01"
                        min="0.01"
                        placeholder="0.00"
                        class="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm focus:border-[#40e0d0] focus:ring-2 focus:ring-[#40e0d0]/30 focus:outline-none"
                    />
                </div>
                <div>
                    <label class="block text-xs font-medium text-slate-600">Payment Method</label>
                    <select
                        v-model="form.payment_method"
                        class="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm focus:border-[#40e0d0] focus:ring-2 focus:ring-[#40e0d0]/30 focus:outline-none"
                    >
                        <option value="cash">Cash</option>
                        <option value="transfer">Bank Transfer</option>
                        <option value="card">Card</option>
                        <option value="cheque">Cheque</option>
                        <option value="pos">POS</option>
                    </select>
                </div>
                <div>
                    <label class="block text-xs font-medium text-slate-600">Payment Date</label>
                    <input
                        v-model="form.payment_date"
                        type="date"
                        class="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm focus:border-[#40e0d0] focus:ring-2 focus:ring-[#40e0d0]/30 focus:outline-none"
                    />
                </div>
                <div>
                    <label class="block text-xs font-medium text-slate-600">Remarks</label>
                    <input
                        v-model="form.remarks"
                        type="text"
                        placeholder="Optional note"
                        class="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm focus:border-[#40e0d0] focus:ring-2 focus:ring-[#40e0d0]/30 focus:outline-none"
                    />
                </div>
            </div>

            <div v-if="form.errors.amount" class="mt-2 text-xs font-medium text-red-600">
                {{ form.errors.amount }}
            </div>

            <div class="mt-4 flex flex-wrap items-center gap-3">
                <button
                    type="button"
                    :disabled="form.processing"
                    @click="settle"
                    class="inline-flex items-center gap-2 rounded-xl bg-[#FACC15] px-4 py-2 text-sm font-semibold text-[#0D1527] shadow-sm hover:bg-[#e6b800] disabled:cursor-not-allowed disabled:opacity-60"
                >
                    <i class="bi bi-cash-coin"></i>
                    {{ form.processing ? 'Recording…' : 'Record Payment' }}
                </button>
                <p class="text-xs text-slate-400">
                    Outstanding balance: <strong class="text-slate-600">{{ naira(outstanding()) }}</strong>
                </p>
            </div>
        </div>

        <div class="grid grid-cols-2 gap-4 lg:grid-cols-4">
            <div class="rounded-2xl border border-slate-200/80 bg-white p-4 shadow-xs">
                <p class="text-xs font-medium uppercase tracking-wide text-slate-500">Lifetime Purchases</p>
                <p class="mt-2 text-2xl font-bold text-slate-900">{{ naira(totals.sales_sum) }}</p>
            </div>
            <div class="rounded-2xl border border-slate-200/80 bg-white p-4 shadow-xs">
                <p class="text-xs font-medium uppercase tracking-wide text-slate-500">Invoices / Count</p>
                <p class="mt-2 text-2xl font-bold text-slate-900">{{ totals.count }}</p>
            </div>
            <div class="rounded-2xl border border-slate-200/80 bg-white p-4 shadow-xs">
                <p class="text-xs font-medium uppercase tracking-wide text-slate-500">Outstanding</p>
                <p class="mt-2 text-2xl font-bold text-amber-700">{{ naira(totals.outstanding) }}</p>
            </div>
            <div class="rounded-2xl border border-slate-200/80 bg-white p-4 shadow-xs">
                <p class="text-xs font-medium uppercase tracking-wide text-slate-500">Contact</p>
                <p class="mt-2 text-sm font-semibold text-slate-700">{{ customer.phone || 'No phone' }}</p>
                <p class="text-xs text-slate-400">{{ customer.email || 'No email' }}</p>
            </div>
        </div>

        <div class="mt-6 space-y-6">
            <div class="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-xs">
                <h2 class="mb-3 text-sm font-semibold text-slate-900">Recent Sales</h2>
                <div v-if="customer.sales?.length" class="space-y-3">
                    <div v-for="s in customer.sales" :key="s.id" class="flex items-center justify-between border-b border-slate-100 pb-3 last:border-0">
                        <div>
                            <p class="font-mono text-xs font-medium text-slate-700">{{ s.invoice_no }}</p>
                            <p class="text-xs text-slate-400">{{ formatDate(s.sale_date) }}</p>
                        </div>
                        <div class="text-right">
                            <p class="text-sm font-semibold text-slate-900">{{ naira(s.total) }}</p>
                            <p class="text-xs" :class="s.balance > 0 ? 'text-amber-700' : 'text-slate-400'">
                                {{ s.balance > 0 ? `Bal: ${naira(s.balance)}` : 'Paid' }}
                            </p>
                        </div>
                    </div>
                </div>
                <p v-else class="py-8 text-center text-sm text-slate-400">No sales yet.</p>
            </div>

            <div class="overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-xs">
                <div class="flex items-center justify-between gap-4 border-b border-slate-100 px-5 py-4">
                    <div>
                        <h2 class="text-sm font-semibold text-slate-900">All Payments</h2>
                        <p class="text-xs text-slate-400">
                            {{ payments_meta.count }} payment{{ payments_meta.count === 1 ? '' : 's' }} ·
                            Received {{ naira(payments_meta.received) }}
                            <template v-if="payments_meta.paid_out > 0">
                                · Paid out {{ naira(payments_meta.paid_out) }}
                            </template>
                        </p>
                    </div>
                    <Link
                        v-if="has('payments.view')"
                        href="/admin/payments"
                        class="whitespace-nowrap text-xs font-semibold text-[#0D1527] underline underline-offset-2 hover:text-[#40e0d0]"
                    >
                        All payments
                    </Link>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-slate-200 text-sm">
                        <thead class="bg-slate-50">
                            <tr>
                                <th class="px-5 py-3 text-left font-semibold text-slate-600">Reference</th>
                                <th class="px-5 py-3 text-left font-semibold text-slate-600">Date</th>
                                <th class="px-5 py-3 text-left font-semibold text-slate-600">Type</th>
                                <th class="px-5 py-3 text-left font-semibold text-slate-600">Method</th>
                                <th class="px-5 py-3 text-right font-semibold text-slate-600">Amount</th>
                                <th class="px-5 py-3 text-right font-semibold text-slate-600">Status</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            <tr v-for="p in payments.data" :key="p.id" class="hover:bg-slate-50">
                                <td class="px-5 py-3">
                                    <span class="font-mono text-xs font-medium text-slate-900">{{ p.ref_id }}</span>
                                    <p class="text-xs text-slate-400">{{ p.document_type }} #{{ p.document_id }}</p>
                                </td>
                                <td class="px-5 py-3 text-slate-600">{{ formatDateTime(p.payment_date) }}</td>
                                <td class="px-5 py-3">
                                    <span :class="badgeClass(p.type === 'payment_in' ? 'bg-emerald-100 text-emerald-800' : 'bg-orange-100 text-orange-800')">
                                        {{ p.type === 'payment_in' ? 'In' : 'Out' }}
                                    </span>
                                </td>
                                <td class="px-5 py-3 capitalize text-slate-600">{{ p.payment_method }}</td>
                                <td class="px-5 py-3 text-right font-semibold" :class="p.type === 'payment_in' ? 'text-emerald-700' : 'text-red-700'">
                                    {{ p.type === 'payment_in' ? '+' : '-' }}{{ naira(p.amount) }}
                                </td>
                                <td class="px-5 py-3 text-right">
                                    <span :class="statusBadge(p.status)">{{ p.status }}</span>
                                </td>
                            </tr>
                            <tr v-if="!payments.data?.length">
                                <td colspan="6" class="px-5 py-12 text-center text-sm text-slate-400">
                                    No payments recorded yet.
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="border-t border-slate-100 px-4 py-3">
                    <Pagination :meta="payments" />
                </div>
            </div>
        </div>
</template>