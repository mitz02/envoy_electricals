<script setup>
import { ref, computed } from 'vue';
import { Link, router, Head } from '@inertiajs/vue3';
import PublicLayout from '@/Layouts/PublicLayout.vue';
import FlashMessages from '@/Components/FlashMessages.vue';
import { naira, badgeClass } from '@/lib/format';

defineOptions({ layout: PublicLayout });

const props = defineProps({
    order: { type: Object, required: true },
    payments: { type: Array, default: () => [] },
    paid: { type: Number, default: 0 },
    balance: { type: Number, default: 0 },
    bank: { type: Object, default: () => ({}) },
    whatsappNumber: { type: String, default: '' },
});

const whatsapp = computed(() => (props.whatsappNumber || '2348097089259').replace(/\D/g, ''));

const waProofLink = computed(() => {
    const lines = [
        `Hello Envoy! I just made a bank transfer for order ${props.order.ref_id}.`,
        `Order reference: ${props.order.ref_id}`,
        `Amount paid: ${naira(props.balance, 2)}`,
        `Name: ${props.order.customer_name}`,
        'Here is my proof of payment.',
    ];
    return `https://wa.me/${whatsapp.value}?text=${encodeURIComponent(lines.filter(Boolean).join('\n'))}`;
});

const offlineSubmitting = ref(false);
const copied = ref('');

// Safe-access the dotted setting keys the backend stores.
const bankName = computed(() => props.bank['bank.bank_name'] || 'Moniepoint MFB');
const accountName = computed(() => props.bank['bank.account_name'] || 'Envoy Electricals Ltd.');
const accountNumber = computed(() => props.bank['bank.account_number'] || '5168265608');

const isClosed = computed(() => ['cancelled', 'refunded'].includes(props.order.status));
const isPaid = computed(() => props.balance <= 0 || isClosed.value);

async function copyValue(label, value) {
    try {
        await navigator.clipboard.writeText(value);
        copied.value = label;
        setTimeout(() => {
            if (copied.value === label) copied.value = '';
        }, 2000);
    } catch {
        // Clipboard unavailable; no-op.
    }
}

function confirmOffline() {
    offlineSubmitting.value = true;
    router.post(`/orders/${props.order.ref_id}/offline`, {}, { onFinish: () => { offlineSubmitting.value = false; } });
}

const statusBadge = {
    pending: badgeClass('bg-amber-100 text-amber-800'),
    paid: badgeClass('bg-emerald-100 text-emerald-800'),
    processing: badgeClass('bg-sky-100 text-sky-800'),
    completed: badgeClass('bg-emerald-100 text-emerald-800'),
    cancelled: badgeClass('bg-slate-200 text-slate-600'),
    refunded: badgeClass('bg-slate-200 text-slate-600'),
};
</script>

<template>
    <Head>
        <meta name="robots" content="noindex, nofollow" />
    </Head>
    <FlashMessages />
    <div class="mx-auto max-w-2xl px-4 py-10 sm:px-6">
        <!-- Back to payment options -->
        <Link
            :href="`/orders/${order.ref_id}/pay`"
            class="inline-flex items-center gap-1.5 text-sm font-medium text-slate-500 transition hover:text-slate-900"
        >
            <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
            </svg>
            Back to payment options
        </Link>

        <div class="mt-4 flex flex-wrap items-center justify-between gap-3">
            <div>
                <h1 class="text-2xl font-black text-slate-900">Pay by Bank Transfer</h1>
                <p class="mt-1 text-sm text-slate-500">
                    Order {{ order.ref_id }} ·
                    <span :class="statusBadge[order.status]">{{ order.status }}</span>
                </p>
            </div>
        </div>

        <!-- Closed / paid state -->
        <div v-if="isPaid" class="mt-8 rounded-2xl border border-emerald-200 bg-emerald-50 p-6 text-center">
            <p class="text-lg font-black text-emerald-800">
                {{ isClosed ? 'Order not payable' : 'Order paid — thank you!' }}
            </p>
            <p class="mt-2 text-sm text-emerald-700">
                {{ isClosed
                    ? 'This order has been closed and can no longer be paid.'
                    : "There's nothing left to pay on this order." }}
            </p>
            <Link
                :href="`/orders/${order.ref_id}/pay`"
                class="mt-4 inline-block text-sm font-semibold text-slate-900 underline hover:text-slate-600"
            >
                View order status
            </Link>
        </div>

        <template v-else>
            <!-- Amount to pay -->
            <div class="mt-8 flex items-center justify-between gap-3 rounded-2xl border border-slate-100 bg-[#FAF8F2] px-6 py-5">
                <div>
                    <p class="text-[11px] font-bold uppercase tracking-wider text-slate-500">Amount to pay</p>
                    <p class="mt-0.5 text-3xl font-black text-slate-900">{{ naira(balance, 2) }}</p>
                </div>
                <span class="rounded-lg bg-[#0D1527] px-3 py-1.5 font-mono text-xs font-bold text-yellow-400">{{ order.ref_id }}</span>
            </div>

            <!-- Bank details -->
            <div class="mt-6 rounded-2xl border border-slate-200/80 bg-white p-6 shadow-xs">
                <h2 class="text-sm font-semibold uppercase tracking-wide text-slate-500">Bank account details</h2>
                <div class="mt-4 space-y-4">
                    <div class="flex items-center justify-between gap-3 border-b border-slate-100 pb-4">
                        <div>
                            <p class="text-xs text-slate-500">Account name</p>
                            <p class="mt-0.5 font-bold text-slate-900">{{ accountName }}</p>
                        </div>
                        <button
                            type="button"
                            class="shrink-0 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-semibold text-slate-600 transition hover:border-slate-300 hover:bg-slate-50"
                            @click="copyValue('name', accountName)"
                        >
                            {{ copied === 'name' ? 'Copied ✓' : 'Copy' }}
                        </button>
                    </div>

                    <div class="flex items-center justify-between gap-3 border-b border-slate-100 pb-4">
                        <div>
                            <p class="text-xs text-slate-500">Account number</p>
                            <p class="mt-0.5 font-mono text-xl font-black tracking-widest text-slate-900">{{ accountNumber }}</p>
                        </div>
                        <button
                            type="button"
                            class="shrink-0 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-semibold text-slate-600 transition hover:border-slate-300 hover:bg-slate-50"
                            @click="copyValue('number', accountNumber)"
                        >
                            {{ copied === 'number' ? 'Copied ✓' : 'Copy' }}
                        </button>
                    </div>

                    <div class="flex items-center justify-between gap-3">
                        <div>
                            <p class="text-xs text-slate-500">Bank</p>
                            <p class="mt-0.5 font-bold text-slate-900">{{ bankName }}</p>
                        </div>
                        <button
                            type="button"
                            class="shrink-0 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-semibold text-slate-600 transition hover:border-slate-300 hover:bg-slate-50"
                            @click="copyValue('bank', bankName)"
                        >
                            {{ copied === 'bank' ? 'Copied ✓' : 'Copy' }}
                        </button>
                    </div>
                </div>

                <p class="mt-5 rounded-xl bg-amber-50 px-4 py-3 text-xs leading-relaxed text-amber-800">
                    Use <strong>{{ order.ref_id }}</strong> as the transfer narration so we can match your payment quickly.
                </p>
            </div>

            <!-- WhatsApp proof CTA -->
            <div class="mt-6 rounded-2xl bg-[#0D1527] p-6 text-white">
                <h2 class="text-sm font-semibold uppercase tracking-wide text-slate-300">After you transfer</h2>
                <p class="mt-2 text-sm leading-relaxed text-slate-300">
                    Send us your proof of payment on WhatsApp so we can verify and confirm your order within business hours.
                </p>
                <a
                    :href="waProofLink"
                    target="_blank"
                    rel="noopener"
                    class="mt-5 flex items-center justify-center gap-2.5 rounded-xl bg-[#25D366] px-6 py-3.5 text-sm font-bold text-white shadow-lg shadow-green-500/20 transition hover:bg-[#1fb858]"
                >
                    <i class="bi bi-whatsapp text-lg leading-none"></i>
                    Send proof of payment on WhatsApp
                </a>
                <p class="mt-2 text-center text-xs text-slate-400">Attach your transfer screenshot and tap send.</p>
            </div>

            <div class="my-5 flex items-center gap-3 text-xs uppercase tracking-wide text-slate-400">
                <span class="h-px flex-1 bg-slate-200" />or<span class="h-px flex-1 bg-slate-200" />
            </div>

            <!-- Confirm transfer -->
            <button
                type="button"
                class="w-full rounded-xl border border-slate-300 bg-white px-6 py-3.5 text-sm font-semibold text-slate-800 transition hover:bg-slate-50 disabled:opacity-50"
                :disabled="offlineSubmitting"
                @click="confirmOffline"
            >
                {{ offlineSubmitting ? 'Confirming…' : 'I have already transferred' }}
            </button>
            <p class="mt-2 text-center text-xs text-slate-400">We verify every transfer before confirming your order.</p>

            <!-- Payments history -->
            <div v-if="payments.length" class="mt-8 rounded-2xl border border-slate-200/80 bg-white p-6 shadow-xs">
                <h2 class="text-sm font-semibold uppercase tracking-wide text-slate-500">Payments</h2>
                <ul class="mt-3 space-y-2 text-sm">
                    <li v-for="p in payments" :key="p.id" class="flex items-center justify-between">
                        <div>
                            <span class="font-mono text-xs font-medium text-slate-700">{{ p.ref_id }}</span>
                            <span class="ml-2 text-slate-600 capitalize">{{ p.payment_method }}</span>
                        </div>
                        <div class="flex items-center gap-2">
                            <span class="font-semibold text-slate-900">{{ naira(p.amount, 2) }}</span>
                            <span :class="badgeClass(p.status === 'success' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800')">{{ p.status }}</span>
                        </div>
                    </li>
                </ul>
            </div>
        </template>
    </div>
</template>