<script setup>
import { ref, computed } from 'vue';
import { Link, Head } from '@inertiajs/vue3';
import axios from 'axios';
import PublicLayout from '@/Layouts/PublicLayout.vue';
import FlashMessages from '@/Components/FlashMessages.vue';
import { naira, badgeClass } from '@/lib/format';

defineOptions({ layout: PublicLayout });

const props = defineProps({
    order: { type: Object, required: true },
    payments: { type: Array, default: () => [] },
    paid: { type: Number, default: 0 },
    balance: { type: Number, default: 0 },
    paystackConfigured: { type: Boolean, default: false },
    businessEmail: { type: String, default: '' },
    bank: { type: Object, default: () => ({}) },
    whatsappNumber: { type: String, default: '' },
});

const whatsapp = computed(() => (props.whatsappNumber || '2348097089259').replace(/\D/g, ''));

const paying = ref(false);
const payloadError = ref('');
const paystackError = ref('');

const isPaid = computed(() => props.balance <= 0 || ['cancelled', 'refunded'].includes(props.order.status));

function imageUrl(item) {
    const img = item?.product?.images?.[0]?.path ?? item?.product?.image ?? '';
    return img && !img.startsWith('/images/') ? `/storage/${img}` : '/images/landing/solar_products.jpg';
}

async function payWithPaystack() {
    if (!props.order.customer_email && !props.businessEmail) {
        payloadError.value = 'We need an email to create the Paystack payment.';
        return;
    }

    paying.value = true;
    paystackError.value = '';
    payloadError.value = '';

    try {
        const { data } = await axios.post(`/orders/${props.order.ref_id}/paystack`);
        window.open(data.authorization_url, '_blank');
    } catch (e) {
        paystackError.value = e.response?.data?.message ?? 'Something went wrong. Please try again.';
    } finally {
        paying.value = false;
    }
}

const statusBadge = {
    pending: badgeClass('bg-amber-100 text-amber-800'),
    paid: badgeClass('bg-emerald-100 text-emerald-800'),
    processing: badgeClass('bg-sky-100 text-sky-800'),
    completed: badgeClass('bg-emerald-100 text-emerald-800'),
    cancelled: badgeClass('bg-slate-200 text-slate-600'),
    refunded: badgeClass('bg-slate-200 text-slate-600'),
};
</script>

<template>
    <Head>
        <meta name="robots" content="noindex, nofollow" />
    </Head>
    <FlashMessages />
    <div class="mx-auto max-w-4xl px-4 py-10 sm:px-6">
        <div class="flex flex-wrap items-center justify-between gap-3">
            <div>
                <h1 class="text-2xl font-black text-slate-900">Order {{ order.ref_id }}</h1>
                <p class="mt-1 text-sm text-slate-500">
                    Placed {{ new Date(order.created_at).toLocaleString('en-GB') }} ·
                    <span :class="statusBadge[order.status]">{{ order.status }}</span>
                </p>
            </div>
            <Link href="/shop" class="text-sm font-medium text-slate-600 underline hover:text-slate-900">Continue shopping</Link>
        </div>

        <div class="mt-8 grid gap-6 lg:grid-cols-5">
            <div class="space-y-6 lg:col-span-3">
                <div class="overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-xs">
                    <div class="border-b border-slate-100 px-6 py-4">
                        <h2 class="text-sm font-semibold uppercase tracking-wide text-slate-500">Items</h2>
                    </div>
                    <ul class="divide-y divide-slate-100">
                        <li v-for="item in order.items" :key="item.id" class="flex items-start gap-4 px-6 py-4">
                            <img :src="imageUrl(item)" alt="" class="h-14 w-14 rounded-xl object-cover" />
                            <div class="min-w-0 flex-1">
                                <p class="font-semibold text-slate-900">{{ item.product?.name ?? `Product #${item.product_id}` }}</p>
                                <p class="text-sm text-slate-500">
                                    {{ item.quantity }} × {{ naira(item.unit_price, 2) }}
                                </p>
                            </div>
                            <p class="text-sm font-semibold text-slate-900">{{ naira(item.total, 2) }}</p>
                        </li>
                    </ul>
                    <div class="space-y-1.5 border-t border-slate-100 px-6 py-4 text-sm">
                        <div class="flex justify-between text-slate-600"><span>Subtotal</span><span>{{ naira(order.subtotal, 2) }}</span></div>
                        <div v-if="order.discount > 0" class="flex justify-between text-emerald-700"><span>Discount</span><span>−{{ naira(order.discount, 2) }}</span></div>
                        <div v-if="order.tax > 0" class="flex justify-between text-slate-600"><span>Tax</span><span>{{ naira(order.tax, 2) }}</span></div>
                        <div v-if="order.delivery_fee > 0" class="flex justify-between text-slate-600"><span>Delivery fee</span><span>{{ naira(order.delivery_fee, 2) }}</span></div>
                        <div class="flex justify-between border-t border-slate-100 pt-2 text-lg font-black text-slate-900">
                            <span>Total</span><span>{{ naira(order.total, 2) }}</span>
                        </div>
                        <div class="flex justify-between pt-1 font-semibold text-emerald-700">
                            <span>Paid</span><span>{{ naira(paid, 2) }}</span>
                        </div>
                        <div class="flex justify-between font-bold" :class="balance > 0 ? 'text-red-600' : 'text-emerald-800'">
                            <span>Balance due</span><span>{{ naira(balance, 2) }}</span>
                        </div>
                    </div>
                </div>

                <div class="rounded-2xl border border-slate-200/80 bg-white p-6 shadow-xs">
                    <h2 class="text-sm font-semibold uppercase tracking-wide text-slate-500">Delivery details</h2>
                    <dl class="mt-3 space-y-1.5 text-sm">
                        <div class="flex gap-2"><dt class="w-24 font-medium text-slate-600">Name:</dt><dd class="text-slate-900">{{ order.customer_name }}</dd></div>
                        <div class="flex gap-2"><dt class="w-24 font-medium text-slate-600">Phone:</dt><dd class="text-slate-900">{{ order.customer_phone }}</dd></div>
                        <div v-if="order.customer_email" class="flex gap-2"><dt class="w-24 font-medium text-slate-600">Email:</dt><dd class="text-slate-900">{{ order.customer_email }}</dd></div>
                        <div class="flex gap-2"><dt class="w-24 font-medium text-slate-600">Address:</dt><dd class="text-slate-900">{{ order.delivery_address }}</dd></div>
                        <div class="flex gap-2">
                            <dt class="w-24 font-medium text-slate-600">Fulfilment:</dt>
                            <dd class="capitalize text-slate-900">{{ order.fulfillment }}</dd>
                        </div>
                    </dl>
                </div>

                <div v-if="payments.length" class="rounded-2xl border border-slate-200/80 bg-white p-6 shadow-xs">
                    <h2 class="text-sm font-semibold uppercase tracking-wide text-slate-500">Payments</h2>
                    <ul class="mt-3 space-y-2 text-sm">
                        <li v-for="p in payments" :key="p.id" class="flex items-center justify-between">
                            <div>
                                <span class="font-mono text-xs font-medium text-slate-700">{{ p.ref_id }}</span>
                                <span class="ml-2 text-slate-600 capitalize">{{ p.payment_method }}</span>
                            </div>
                            <div class="flex items-center gap-2">
                                <span class="font-semibold text-slate-900">{{ naira(p.amount, 2) }}</span>
                                <span :class="badgeClass(p.status === 'success' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800')">{{ p.status }}</span>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="lg:col-span-2">
                <div v-if="isPaid" class="rounded-2xl border border-emerald-200 bg-emerald-50 p-6">
                    <p class="text-lg font-black text-emerald-800">
                        {{ order.status === 'cancelled' || order.status === 'refunded' ? 'Order not payable' : 'Order paid — thank you!' }}
                    </p>
                    <p class="mt-2 text-sm text-emerald-700">
                        {{ order.status === 'cancelled' || order.status === 'refunded'
                            ? 'This order has been closed and can no longer be paid.'
                            : 'Your payment has been received. We will dispatch your order shortly.' }}
                    </p>
                </div>

                <div v-else class="space-y-4">
                    <div class="rounded-2xl border border-slate-200/80 bg-white p-6 shadow-xs">
                        <h2 class="text-sm font-semibold uppercase tracking-wide text-slate-500">Pay {{ naira(balance, 2) }}</h2>

                        <template v-if="paystackConfigured">
                            <button
                                type="button"
                                class="mt-4 w-full rounded-xl bg-[#0D1527] px-6 py-3 text-sm font-semibold text-white hover:bg-slate-800 disabled:opacity-50"
                                :disabled="paying"
                                @click="payWithPaystack"
                            >
                                {{ paying ? 'Contacting Paystack…' : 'Pay Online with Paystack' }}
                            </button>
                            <p v-if="payloadError" class="mt-2 text-xs text-red-600">{{ payloadError }}</p>
                            <p v-if="paystackError" class="mt-2 text-xs text-red-600">{{ paystackError }}</p>
                            <div class="my-4 flex items-center gap-3 text-xs uppercase tracking-wide text-slate-400">
                                <span class="h-px flex-1 bg-slate-200" />or<span class="h-px flex-1 bg-slate-200" />
                            </div>
                        </template>
                        <p v-else class="mt-3 text-sm text-slate-500">Online card payment is currently unavailable.</p>

                        <Link
                            :href="`/orders/${order.ref_id}/pay/bank-transfer`"
                            class="flex w-full items-center justify-center rounded-xl border border-slate-300 bg-white px-6 py-3 text-sm font-semibold text-slate-800 transition hover:border-slate-400 hover:bg-slate-50"
                        >
                            Pay by Bank Transfer
                        </Link>
                    </div>

                    <div class="rounded-2xl border border-amber-200 bg-amber-50 p-5 text-sm text-amber-800">
                        <p class="font-semibold">How offline transfers work</p>
                        <p class="mt-1">Transfer the exact amount to the bank details shown, then click "I have transferred". Our team verifies and confirms your order within business hours.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ===================== WHATSAPP FLOAT ===================== -->
    <a
        :href="`https://wa.me/${whatsapp}`"
        target="_blank"
        rel="noopener"
        title="Chat on WhatsApp"
        class="fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-white shadow-[0_6px_18px_rgba(37,211,102,0.4)] transition-all duration-200 hover:-translate-y-1 hover:bg-[#1fb858] active:translate-y-0 sm:h-16 sm:w-16"
    >
        <svg class="h-7 w-7 sm:h-8 sm:w-8" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm4.5 13c-.2.2-1.4.7-1.7.8s-.4.1-.7 0-.9-.3-1.4-.7a5.6 5.6 0 0 1-1.9-2.5c-.1-.2.2-.4.4-.6l.4-.6a.8.8 0 0 0 .1-.2.5.5 0 0 0 0-.4c-.1-.2-.6-1.4-.8-1.9s-.4-.4-.6-.4h-.5a.8.8 0 0 0-.6.3 2.6 2.6 0 0 0-.8 1.9 4.5 4.5 0 0 0 .9 2.4 10 10 0 0 0 3.9 3.4c1.2.6 1.7.6 2.1.6a2.6 2.6 0 0 0 1.7-1.2 2 2 0 0 0 .1-1.2z"/></svg>
        <span class="absolute -top-1 -right-1 h-4 w-4 rounded-full border-2 border-white bg-[#E4312B]"></span>
    </a>
</template>