<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Permission;
use App\Models\Role;
use App\Services\AuditLogger;
use App\Support\RoleAccess;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Inertia\Inertia;
use Inertia\Response;

class RoleAccessController extends Controller
{
    public function index(): Response
    {
        abort_unless(request()->user()->isSuperAdmin(), 403, 'Only the super admin can manage access control.');

        $roles = Role::with('permissions')
            ->orderBy('id')
            ->get()
            ->map(fn (Role $role) => [
                'id' => $role->id,
                'name' => $role->name,
                'slug' => $role->slug,
                'description' => $role->description,
                'is_owner' => $role->slug === 'owner',
                'staff_count' => $role->users()->count(),
                'permission_slugs' => $role->permissions->pluck('slug')->values(),
                'masked_fields' => $role->maskedFields(),
            ]);

        $permissions = Permission::orderBy('module')->orderBy('name')
            ->get(['id', 'slug', 'module', 'description', 'name'])
            ->groupBy('module')
            ->map(fn ($perms) => $perms->map(fn ($p) => [
                'slug' => $p->slug,
                'name' => $p->name,
                'description' => $p->description,
            ])->values());

        return Inertia::render('Admin/Settings/Roles', [
            'roles' => $roles,
            'permission_modules' => $permissions,
            'maskable_fields' => RoleAccess::maskableFields(),
        ]);
    }

    public function update(Request $request, Role $role): RedirectResponse
    {
        abort_unless($request->user()->isSuperAdmin(), 403, 'Only the super admin can manage access control.');
        abort_unless($role->slug !== 'owner', 403, 'The super admin role cannot be changed.');

        $data = $request->validate([
            'permissions' => ['array'],
            'permissions.*' => ['string', 'exists:permissions,slug'],
            'masked_fields' => ['array'],
            'masked_fields.*' => ['string', Rule::in(RoleAccess::maskableSlugs())],
        ]);

        $permissionIds = Permission::whereIn('slug', $data['permissions'] ?? [])->pluck('id');

        $role->permissions()->sync($permissionIds);
        $role->forceFill([
            'access_config' => [
                'masked_fields' => array_values(array_unique($data['masked_fields'] ?? [])),
            ],
        ])->save();

        AuditLogger::log('updated', 'role', $role->id, "Updated access for role {$role->name} ({$role->slug}).");

        return redirect()->back()->with('success', "Access settings saved for the {$role->name} role.");
    }
}