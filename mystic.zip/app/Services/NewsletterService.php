<?php

namespace App\Services;

use App\Mail\NewsletterMail;
use App\Models\Newsletter;
use App\Models\NewsletterSubscriber;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class NewsletterService
{
    /**
     * Send a newsletter to every subscribed subscriber.
     *
     * @param  bool  $markSent  Update status/sent_at once dispatched.
     * @return array{delivered: int, failed: int, failures: array<int, string>}
     */
    public function send(Newsletter $newsletter, bool $markSent = true): array
    {
        $recipients = NewsletterSubscriber::query()
            ->where('status', 'subscribed')
            ->get();

        $delivered = 0;
        $failed = 0;
        $failures = [];

        foreach ($recipients as $subscriber) {
            if (empty($subscriber->token)) {
                $subscriber->token = \Illuminate\Support\Str::random(40);
                $subscriber->save();
            }

            try {
                Mail::to($subscriber->email, $subscriber->name)
                    ->send(new NewsletterMail($newsletter, $subscriber));
                $delivered++;
            } catch (\Throwable $e) {
                $failed++;
                $failures[] = $subscriber->email;

                Log::error('Newsletter delivery failed', [
                    'newsletter_id' => $newsletter->id,
                    'subscriber' => $subscriber->email,
                    'error' => $e->getMessage(),
                ]);
            }
        }

        if ($markSent) {
            $this->markSent($newsletter);
        }

        return [
            'delivered' => $delivered,
            'failed' => $failed,
            'failures' => $failures,
        ];
    }

    public function markSent(Newsletter $newsletter): void
    {
        $newsletter->update([
            'status' => 'sent',
            'sent_at' => now(),
            'scheduled_at' => null,
        ]);
    }

    /**
     * Dispatch every overdue scheduled newsletter.
     */
    public function sendScheduled(): array
    {
        $scheduled = Newsletter::query()
            ->where('status', 'scheduled')
            ->whereNotNull('scheduled_at')
            ->where('scheduled_at', '<=', now())
            ->get();

        $sent = 0;

        foreach ($scheduled as $newsletter) {
            $this->send($newsletter);
            $sent++;
        }

        return ['sent_newsletters' => $sent, 'total' => $scheduled->count()];
    }
}