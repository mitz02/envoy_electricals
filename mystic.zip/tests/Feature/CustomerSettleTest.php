<?php

namespace Tests\Feature;

use App\Models\Customer;
use App\Models\Payment;
use App\Models\Product;
use App\Models\Role;
use App\Models\User;
use App\Services\InventoryService;
use App\Services\SaleService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class CustomerSettleTest extends TestCase
{
    use RefreshDatabase;

    protected function owner(): User
    {
        $this->seed(\Database\Seeders\RolesAndPermissionsSeeder::class);

        return User::factory()->create([
            'role_id' => Role::where('slug', 'owner')->first()->id,
        ]);
    }

    protected function customer(string $name): Customer
    {
        return Customer::create([
            'ref_id' => 'SET-CUS-' . mt_rand(10000, 99999),
            'name' => $name,
            'phone' => '080' . mt_rand(1000000, 9999999),
            'customer_type' => 'regular',
        ]);
    }

    protected function createSale(Customer $customer, float $total, float $paid, string $date): void
    {
        $product = Product::create([
            'ref_id' => 'SET-PROD-' . mt_rand(10000, 99999),
            'name' => 'Settle Product ' . mt_rand(1000, 9999),
            'sku' => 'SET-' . strtoupper(substr(md5($customer->id . $date . $total), 0, 8)),
            'unit' => 'piece',
            'selling_price' => 0,
        ]);

        app(InventoryService::class)->setOpeningStock($product, 20, 1000);

        app(SaleService::class)->createSale(
            [
                'sale_date' => $date,
                'customer_id' => $customer->id,
                'amount_paid' => $paid,
                'payment_method' => 'cash',
                'remarks' => 'settle test',
            ],
            [['product_id' => $product->id, 'quantity' => 1, 'unit_price' => $total]],
            $this->owner()->id,
        );
    }

    public function test_settle_partial_payment_reduces_oldest_invoice_and_records_payment(): void
    {
        $owner = $this->owner();
        $customer = $this->customer('Ada Obi');
        $this->createSale($customer, 50000, 30000, now()->subDays(5)->toDateString()); // balance 20000
        $this->createSale($customer, 10000, 10000, now()->toDateString());            // balance 0

        $this->actingAs($owner)
            ->post("/admin/customers/{$customer->id}/settle", [
                'amount' => 8000,
                'payment_method' => 'transfer',
                'payment_date' => now()->toDateString(),
                'remarks' => 'partial payment',
            ])
            ->assertRedirect()
            ->assertSessionHas('success', fn (string $m) => str_contains($m, 'Payment of'));

        $invoice = $customer->sales()->where('balance', '>', 0)->first();
        $this->assertSame(12000.0, (float) $invoice->balance);
        $this->assertSame(12000.0, $customer->refresh()->outstandingBalance());

        $payment = Payment::where('customer_id', $customer->id)->latest('id')->first();
        $this->assertNotNull($payment);
        $this->assertSame('payment_in', $payment->type);
        $this->assertSame('sale', $payment->document_type);
        $this->assertSame(8000.0, (float) $payment->amount);
    }

    public function test_settle_full_balance_clears_all_outstanding_invoices(): void
    {
        $owner = $this->owner();
        $customer = $this->customer('Bola Ridge');
        $this->createSale($customer, 5000, 1500, now()->subDays(3)->toDateString()); // balance 3500
        $this->createSale($customer, 10000, 4000, now()->toDateString());            // balance 6000

        $settledBefore = Payment::where('customer_id', $customer->id)->count();

        $this->actingAs($owner)
            ->post("/admin/customers/{$customer->id}/settle", [
                'amount' => 9500,
                'payment_method' => 'cash',
            ])
            ->assertRedirect();

        $this->assertSame(0.0, $customer->refresh()->outstandingBalance());
        $this->assertSame(0, (int) $customer->sales()->where('balance', '>', 0)->count());

        $settlePayments = Payment::where('customer_id', $customer->id)
            ->orderByDesc('id')->take(2)->get();
        $this->assertSame(9500.0, (float) $settlePayments->sum('amount'));
        $this->assertSame($settledBefore + 2, Payment::where('customer_id', $customer->id)->count());
    }

    public function test_settle_allocates_across_invoices_oldest_first(): void
    {
        $owner = $this->owner();
        $customer = $this->customer('Chidi Ok');
        $this->createSale($customer, 5000, 1500, now()->subDays(3)->toDateString()); // balance 3500 (oldest)
        $this->createSale($customer, 10000, 4000, now()->toDateString());            // balance 6000

        $this->actingAs($owner)
            ->post("/admin/customers/{$customer->id}/settle", [
                'amount' => 5000,
                'payment_method' => 'cash',
            ])
            ->assertRedirect();

        $balances = $customer->sales()->orderBy('sale_date')
            ->orderBy('id')->get('balance')->map(fn ($s) => (float) $s->balance)->all();

        $this->assertSame([0.0, 4500.0], $balances);
    }

    public function test_settle_cannot_exceed_outstanding_balance(): void
    {
        $owner = $this->owner();
        $customer = $this->customer('Ada Obi');
        $this->createSale($customer, 5000, 1500, now()->toDateString()); // balance 3500

        $before = Payment::count();

        $this->actingAs($owner)
            ->post("/admin/customers/{$customer->id}/settle", [
                'amount' => 4000,
                'payment_method' => 'cash',
            ])
            ->assertSessionHasErrors('amount');

        $this->assertSame(3500.0, $customer->refresh()->outstandingBalance());
        $this->assertSame($before, Payment::count());
    }

    public function test_requires_manage_permission(): void
    {
        $this->seed(\Database\Seeders\RolesAndPermissionsSeeder::class);
        $user = User::factory()->create([
            'role_id' => Role::where('slug', 'technician')->first()->id,
        ]);
        $customer = $this->customer('Security Tester');
        $this->createSale($customer, 5000, 1500, now()->toDateString());

        $this->actingAs($user)
            ->post("/admin/customers/{$customer->id}/settle", ['amount' => 1000, 'payment_method' => 'cash'])
            ->assertForbidden();
    }

    public function test_customer_show_lists_all_payments(): void
    {
        $owner = $this->owner();
        $customer = $this->customer('Ledger View');
        $this->createSale($customer, 5000, 1500, now()->toDateString()); // initial payment 1500
        $this->createSale($customer, 10000, 4000, now()->toDateString()); // initial payment 4000

        $this->actingAs($owner)
            ->post("/admin/customers/{$customer->id}/settle", [
                'amount' => 9500,
                'payment_method' => 'transfer',
            ])
            ->assertRedirect();

        if (preg_match('/data-page="([^"]*)"/', $this->actingAs($owner)->get("/admin/customers/{$customer->id}")->getContent(), $m)) {
            $page = json_decode(html_entity_decode($m[1], ENT_QUOTES), true);
        } else {
            $this->fail('Unable to parse data-page attribute.');
        }

        $payments = $page['props']['payments'] ?? [];
        $this->assertSame(4, $payments['total']); // 2 initial + 2 settle records
        $this->assertSame(15000.0, (float) $page['props']['payments_meta']['received']);
    }
}